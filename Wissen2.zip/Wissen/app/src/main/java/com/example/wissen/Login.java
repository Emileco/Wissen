package com.example.wissen;

import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import OpenHelper.SQLite_OpenHelper;

public class Login extends AppCompatActivity {

    Button btgrabar;
    EditText etu,etp,etp2;

    SQLite_OpenHelper helper=new SQLite_OpenHelper(this,"Base de datos de Usuarios",null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btgrabar=findViewById(R.id.button);
        etu=findViewById(R.id.usuario);
        etp=findViewById(R.id.txtpass);

        btgrabar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.abrir();
                helper.inreg(String.valueOf(etu.getText()),String.valueOf(etp.getText()));
                helper.cerrar();

                Toast.makeText(getApplicationContext(),"Registro Exitoso",Toast.LENGTH_SHORT).show();

                Intent i=new Intent(Login.this,Login_2.class);
                startActivity(i);
                finish();
            }
        });
    }
}
