package com.example.wissen;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import OpenHelper.SQLite_OpenHelper;

public class Login_2 extends AppCompatActivity {

    ImageButton buti;

    SQLite_OpenHelper helper=new SQLite_OpenHelper(this,"Base de datos de Usuarios",null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_2);

        buti=findViewById(R.id.bi);
    }

    public void registro(View view){
        Intent i=new Intent(Login_2.this,Login.class);
        startActivity(i);
        finish();
    }

    public void err(View view){
        EditText txtusu = findViewById(R.id.usuario);
        EditText txtpass = findViewById(R.id.txtpass);


            Intent i = new Intent(Login_2.this, pantalla_principal.class);
            startActivity(i);
            finish();
    }
}
