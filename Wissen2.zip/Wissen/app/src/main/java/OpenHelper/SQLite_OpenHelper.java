package OpenHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLite_OpenHelper extends SQLiteOpenHelper {
    public SQLite_OpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String Query="create table Usuarios(Id integer primary key  autoincrement, Usuario text, Password text);";
        db.execSQL(Query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    //metodo para abrir la bd
    public void abrir(){
        this.getWritableDatabase();
    }
    //metodo para cerrar la bd
    public void cerrar() {
        this.close();
    }
    //Metodo insertar

    public void inreg(String Usu,String Pas){
        ContentValues val=new ContentValues();
        val.put("Usuario",Usu);
        val.put("Password",Pas);
        this.getWritableDatabase().insert("Usuarios",null,val);
    }

    public Cursor ConsultarUsuPas(String usu,String pas)throws SQLException{
        Cursor mcursor;
        mcursor=this.getReadableDatabase().query("Usuarios",new String[]{"Id","Usuario","Password"},"Usuario like '"+usu+"' and Password like '"+pas+"'", null,null ,null,null);
        return mcursor;
    }
}
