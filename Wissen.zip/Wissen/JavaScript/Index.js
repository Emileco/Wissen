document.addEventListener('keydown', function(Evento){
if(Evento.keyCode == 37){

}
});

//bucle principal
var FPS=10;
setInterval(function(){
    principal();
},100/10);

var canvas,ctx;

function inicializa(){
    canvas=document.getElementById('Canvas');
    ctx=canvas.getContext('2d');
    Imagenes();
}

var Esperma,Ovulo,Cubo;
function Imagenes(){
    Esperma={url: '../imagenes/Espermatozoide.png', cargaOK: true}
    Esperma.imagen=new Image();
    Esperma.imagen.src=Esperma.url;
    Esperma.imagen.addEventListener('load',dibujarEsperma);
}

function dibujarEsperma(){
    ctx.drawImage(Esperma.imagen,0,1,40,12);
}
function borrarCanvas(){
    canvas.width= 500;
    canvas.heigth=500;
}
function principal(){
    borrarCanvas();
    dibujarEsperma();
}
