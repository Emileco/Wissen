package com.example.wissen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Hola(View view){
        Toast.makeText(this,"Hola",Toast.LENGTH_LONG).show();
    }
    public void Adios(View view){
        Toast.makeText(this,"Adios",Toast.LENGTH_LONG).show();
    }
    public void Si(View view){
        Toast.makeText(this,"Si",Toast.LENGTH_LONG).show();
    }
}
