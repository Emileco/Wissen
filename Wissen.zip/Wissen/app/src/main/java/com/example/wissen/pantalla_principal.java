package com.example.wissen;

import android.content.Intent;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class pantalla_principal extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);
            }

    public void crear(View view){
        Intent intent = new Intent(pantalla_principal.this, Login.class);
        startActivity(intent);
        finish();
    }
}
